Feature: Pet Management

  Background:
    * url 'https://petstore.swagger.io/v2'

  Scenario: Successfully add a new pet to the store
    Given path 'pet'
    And request { id: 0, name: 'doggie', photoUrls: [], status: 'available' }
    When method post
    Then status 200
    And match response.name == 'doggie'
    And match response.status == 'available'

  Scenario Outline: Find pets by status
    Given path 'pet', 'findByStatus'
    And param status = '<status>'
    When method get
    Then status 200
    And match each response[*].status == '<status>'

    Examples:
      | status    |
      | available |
      | pending   |
      | sold      |

  Scenario: Attempt to find pets with an invalid status
    Given path 'pet', 'findByStatus'
    And param status = 'invalid_status'
    When method get
    Then status 400

  Scenario: Successfully find an existing pet by its ID
    * def pet_id = 1
    Given path 'pet', pet_id
    When method get
    Then status 200
    And match response.id == pet_id

  Scenario: Attempt to find a pet with a non-existent ID
    Given path 'pet', 999999
    When method get
    Then status 404
    And match response.message == 'Pet not found'

  Scenario: Successfully update an existing pet's name and status
    * def pet_id = 1
    Given path 'pet'
    And request { id: '#(pet_id)', name: 'Snoopy', photoUrls: [], status: 'sold' }
    When method put
    Then status 200
    And match response.name == 'Snoopy'
    And match response.status == 'sold'

  Scenario: Successfully delete an existing pet
    * def pet_id = 1
    Given path 'pet', pet_id
    And header api_key = 'special-key'
    When method delete
    Then status 200

    Given path 'pet', pet_id
    When method get
    Then status 404
