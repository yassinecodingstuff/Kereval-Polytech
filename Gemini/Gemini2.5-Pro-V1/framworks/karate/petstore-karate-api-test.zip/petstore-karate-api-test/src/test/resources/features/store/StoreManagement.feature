Feature: Store Management

  Background:
    * url 'https://petstore.swagger.io/v2'

  Scenario: Successfully place an order for a pet and verify it
    * def order =
      """
      {
        "id": 10,
        "petId": 1,
        "quantity": 1,
        "shipDate": "2025-10-01T18:00:00.000Z",
        "status": "placed",
        "complete": true
      }
      """
    Given path 'store', 'order'
    And request order
    When method post
    Then status 200
    And match response.id == order.id
    And match response.status == 'placed'

  Scenario: Find an existing purchase order by ID
    Given path 'store', 'order', 5
    When method get
    Then status 200
    And match response.id == 5

  Scenario: Attempt to find a purchase order with a non-existent ID
    Given path 'store', 'order', 999999
    When method get
    Then status 404
    And match response.message == 'Order not found'

  Scenario: Successfully delete an existing purchase order
    * def order_id = 8
    Given path 'store', 'order', order_id
    When method delete
    Then status 200

    Given path 'store', 'order', order_id
    When method get
    Then status 404

  Scenario: Retrieve pet inventories by status
    Given path 'store', 'inventory'
    When method get
    Then status 200
    And match response.sold != null
    And match response.available != null
    And match response.pending != null
