Feature: User Management

  Background:
    * url 'https://petstore.swagger.io/v2'
    * def newUser =
      """
      {
        "id": 12345,
        "username": "testuser123",
        "firstName": "Test",
        "lastName": "User",
        "email": "testuser123@example.com",
        "password": "password123",
        "phone": "123-456-7890",
        "userStatus": 1
      }
      """

  Scenario: Create a new user and verify creation
    Given path 'user'
    And request newUser
    When method post
    Then status 200
    And match response.message == 'ok'

  Scenario: Successfully log in with valid credentials
    Given path 'user', 'login'
    And param username = newUser.username
    And param password = newUser.password
    When method get
    Then status 200
    And match response.message contains 'logged in user session:'

  Scenario: Attempt to log in with invalid credentials
    Given path 'user', 'login'
    And param username = newUser.username
    And param password = 'wrongpassword'
    When method get
    Then status 400
    And match response.message == 'Invalid username/password supplied'

  Scenario: Retrieve user details by username
    Given path 'user', newUser.username
    When method get
    Then status 200
    And match response.username == newUser.username
    And match response.email == newUser.email

  Scenario: Attempt to retrieve a user with a non-existent username
    Given path 'user', 'nonexistentuser99'
    When method get
    Then status 404
    And match response.message == 'User not found'

  Scenario: Update an existing user's information and verify
    * def updatedEmail = 'updated.user@example.com'
    * def updatedUser = karate.set(newUser, 'email', updatedEmail)

    Given path 'user', newUser.username
    And request updatedUser
    When method put
    Then status 200

    Given path 'user', newUser.username
    When method get
    Then status 200
    And match response.email == updatedEmail

  Scenario: Successfully log out and end the current session
    Given path 'user', 'login'
    And param username = newUser.username
    And param password = newUser.password
    When method get
    Then status 200

    Given path 'user', 'logout'
    When method get
    Then status 200
    And match response.message == 'ok'
